<?php

namespace App\Livewire\Financial\StudentFees\CourseFees;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Settings\Menu;
use App\Models\Settings\SystemLog;
use App\Models\CenterSettings\Branch;
use App\Models\CenterSettings\DiscountProvider;
use App\Models\Academic\Student;
use App\Models\Academic\CourseStudent;
use App\Models\Academic\Course;
use App\Models\Financial\StudentCourseFee;
use App\Models\CenterSettings\PhysicalBook;
use App\Models\Financial\StudentCourseFeeInstallment;
use App\Models\Financial\StudentCourseFeePayment;
use App\Models\Financial\GeneralDiscount;
use App\Models\Financial\StudentBookFee;
use App\Models\Warehouse\Warehouse;
use App\Models\Warehouse\BookInventory;
use App\Models\Warehouse\BookInventoryMovement;
use App\Models\User;
use App\Notifications\BookExemptionRequestNotification;

use Auth;
use Carbon\Carbon;
use DB;
class StudentCourseFees extends Component
{
    // -------start generals--------------------
    use WithPagination;
    public $perPage = 10;
    protected $paginationTheme = 'bootstrap';   
    public $editMode = false;
    public $active_menu_id;
    public $active_menu;
    public $modalId = 'student-course-fees-addEditModal';
    public $installmentModalId = 'show-installment-modal';
    public $table_name='student_course_fees';
    public $selectedFields = [];
    public $pdfOrientation = 'landscape';
    public $branches=[];

    protected $listeners = ['modalClosed' => 'closeModal','globalDelete' => 'handleGlobalDelete'];

    public function closeModal(){
        $this->resetInputFields();
        $this->resetValidation();
        $this->dispatch('close-modal', id: $this->modalId);

    }

    public function openModal(){
        $this->resetInputFields();
        $this->resetValidation();
        $this->dispatch('open-modal', id: $this->modalId);
    }

    // Hook for real time error message
    public function updated($propertyName)
    {
        if (array_key_exists($propertyName, $this->rules())) {
            $this->validateOnly($propertyName);
        }
    }

    public function updatingPerPage()
    {
        $this->resetPage();
    }
    public function applySearch()
    {
        $this->resetPage();
    }
    
    // ---------------------------------end generals-------------
    public $student;
    public $student_courses = [];
    public $discount_providers = [];
    public $physical_books = [];
    public $selected_physical_books = [];
    public $physical_books_total = 0;
    public function mount($active_menu_id = null, $student_id = null)
    {
        // -------------start for activing menu in sidebar ----------------------
        $this->dispatch('setActiveMenuFromPage', $active_menu_id);
        $this->active_menu_id = $active_menu_id;
        $this->active_menu = Menu::with(['parent', 'grandParent', 'subMenu'])->find($active_menu_id);
        // -------------start for activing menu in sidebar ----------------------

        $this->student =Student::findOrFail($student_id);
        $this->discount_providers =DiscountProvider::where('status',true)->get();
    
        $this->branches =  Branch::all();
    }

        public $branch_id;         
        public $course_id;         
        public $discount_provider_id;         
        public $fee_amount;        
        public $discount_type=null;    
        public $discount_value;  
        public $discount_amount;  
        public $discount_reason;  
        public $g_discount_value;  
        public $g_discount_amount;  
        public $general_discount_amount;  
        public $total_amount;     
        public $payment_type; 
        public $installments = [];
        public $installment_amount;


    public function resetInputFields(){
        $this->resetExcept([
            'active_menu_id',
            'active_menu',
            'table_name',
            'modalId',
            'search',
            'branches',
            'student',
            'student_courses',
            'discount_providers',
        ]);
    }

    public $search = [
            'identity' => null,
            'branch_id' => null,
            'status' => null,
        ];
    
    public function render()
    {
        $feeCourseIds = StudentCourseFee::where('student_id', $this->student->id)
        ->pluck('course_id');
        $this->student_courses = $this->student->courses()
        ->with('book') 
        // ->wherePivot('status', 'active')
        ->whereNotIn('courses.id', $feeCourseIds)  
        ->where('courses.status','!=','archived')  
        ->orderBy('pivot_enrolled_at','desc') 
        ->get();

        $course_fees = StudentCourseFee::with('course')
        ->where('student_id',$this->student->id)
        ->orderBy('id','desc')
        ->paginate($this->perPage);

        return view('livewire.financial.student-fees.course-fees.student-course-fees',compact('course_fees'));
    }

    public function updatedCourseId($courseId)
    {
        $course = $this->student_courses->where('id', $courseId)->first();
        if ($course) {

            $this->fee_amount = $course->book?->fee ?? 0;
            $this->discount_type = $course->discount_type ?? null;
            $this->discount_value = $course->discount_value ?? 0;
            $this->physical_books = PhysicalBook::where('book_id',$course->book_id)->get();
            $this->calculateTotalAmount();

            $this->selected_physical_books = $this->physical_books->map(function ($book) {
                return [
                    'id' => $book->id,
                    'name' => $book->name ?? 'Book #'.$book->id,
                    'price' => $book->price ?? 0,
                    'status' => 'paid',
                ];
            })->toArray();

        $this->calculatePhysicalBooksTotal();
        } else {

            $this->fee_amount = 0;
            $this->discount_type = null;
            $this->discount_value = 0;
            $this->total_amount = 0;
            $this->physical_books = [];
            $this->selected_physical_books = [];
        }
    }

    public $discount_error;

    public function calculateTotalAmount()
    {
        $fee = (float) $this->fee_amount;
        $discount = (float) $this->discount_value;

        $this->total_amount = $fee;
        $this->discount_error = null;

        // ------ General Discount ------------------
        $course = Course::find($this->course_id);
        if ($course) {
            $general_discount = GeneralDiscount::where('status','active')
                ->where('branch_id',$course->branch_id)
                ->where('book_id',$course->book_id)
                ->latest()
                ->first();

            if ($general_discount) {
        
                $this->g_discount_amount = min($general_discount->discount_amount, $course->fee);

                $this->total_amount -= $this->g_discount_amount;

                $this->total_amount = max(0, $this->total_amount);
            }
        }
        // -----------------------------------------

        // ------ Personal Discount Validation ------
        if ($this->discount_type === 'percentage' && $discount > 100) {
            $discount = 100;
            $this->discount_error = "Discount percentage cannot be more than 100%";
        }

        if ($this->discount_type === 'fixed' && $discount > $this->total_amount) {
            $discount = $this->total_amount;
            $this->discount_error = "Discount amount adjusted to remaining total";
        }

        // ------ Apply Personal Discount ----------
        if ($this->discount_type == 'percentage') {
            $this->discount_amount = $this->total_amount * $discount / 100;
        } else { // fixed
            $this->discount_amount = $discount;
        }

        $this->total_amount -= $this->discount_amount;
          
        $this->total_amount = max(0, $this->total_amount);
    }
    
    public function updatedDiscountType($value)
    {   
        if($this->discount_type===''){
            $this->discount_value = null;
        }
        $this->calculateTotalAmount();
    }

    public function updatedDiscountValue($value)
    {
        
        $this->calculateTotalAmount();
        $this->loadProviderDiscountInfo();
    }

    // ----------------store------------------------------

    protected function rules()
    {
        $rules = [
            'course_id' => 'required',
            'payment_type' => 'required',
            'fee_amount' => 'required|numeric',
            'total_amount' => 'required|numeric',
        ];

        if($this->discount_type !=''){
            $rules['discount_value'] = 'required|numeric|gt:0';
            $rules['discount_reason'] = 'required';
        }

        if ($this->payment_type === 'installment') {

           $rules['installment_amount'] = 'required|numeric|min:0|lte:total_amount';
        }

        return $rules;
    }
    // Localized messages
    protected function messages()
    {
        $rules =  [
            'course_id.required' => __('label.course_id.required'),
            'payment_type.required' => __('label.payment_type.required'),
            'fee_amount.required' => __('label.fee_amount.required'),
            'fee_amount.numeric' => __('label.fee_amount.numeric'),

            'total_amount.required' => __('label.total_amount.required'),
            'discount_reason.required' => __('label.discount_reason.required'),
            'total_amount.numeric' => __('label.branch.required'),
            'installment_amount.required' => __('label.installments.*.amount.required'),
        ];

        return $rules;
    }

    public function store()
    {
        if (!add(Auth::user()->role_ids, $this->active_menu_id)) {
            return $this->dispatch('alert', type: 'error', message: __('label.permission_message'));
        }

        if (!$this->loadProviderDiscountInfo() && $this->discount_type) {
            return;
        }

        $this->validate();

        DB::beginTransaction();

        try {

            // جلوگیری از تکرار
            $exists = StudentCourseFee::where('student_id', $this->student->id)
                ->where('course_id', $this->course_id)
                ->exists();

            if ($exists) {
                $this->dispatch('alert',
                    type: 'error',
                    message: 'Fee for this course already exists for this student.'
                );
                return;
            }

            //  تعیین مقدار پرداخت
            $paid = $this->payment_type === 'installment'
                ? $this->installment_amount
                : $this->total_amount;

            $remaining = $this->total_amount - $paid;

            $status = match (true) {
                $remaining <= 0 => 'paid',
                $paid > 0 => 'partial',
                default => 'unpaid',
            };

            //  ایجاد fee
            $studentCourseFee = StudentCourseFee::create([
                'student_id' => $this->student->id,
                'course_id' => $this->course_id,
                'payment_type' => $this->payment_type,
                'fee_amount' => $this->fee_amount,
                'discount_type' => $this->discount_type ?: null,
                'discount_provider_id' => $this->discount_provider_id ?: null,
                'g_discount_value' => $this->g_discount_value ?? 0,
                'g_discount_amount' => $this->g_discount_amount ?? 0,
                'discount_value' => $this->discount_value ?? 0,
                'discount_amount' => $this->discount_amount ?? 0,
                'discount_reason' => $this->discount_reason,
                'total_amount' => $this->total_amount,

                //  مهم
                'paid_amount' => $paid,
                'remaining_amount' => $remaining,
                'status' => $status,

                'branch_id' => $this->student->branch_id,
                'user_id' => auth()->id(),
            ]);

            //  ثبت installment + payment
            $installment = StudentCourseFeeInstallment::create([
                'student_course_fee_id' => $studentCourseFee->id,
                'due_date' => now()->toDateString(),
                'amount' => $paid,
                'status' => 'paid',
            ]);

            StudentCourseFeePayment::firstOrCreate(
                ['installment_id' => $installment->id],
                [
                    'student_course_fee_id' => $installment->student_course_fee_id,
                    'amount' => $installment->amount,
                    'payment_date' => now(),
                    'notes' => $this->payment_type === 'installment' ? 'Installment payment' : 'Full payment',
                    'user_id' => auth()->id(),
                ]
            );

            //  کتاب‌ها
           
            // گرفتن warehouseهای مربوط به branch
            $warehouseIds = Warehouse::where('branch_id', $this->student->branch_id)
                ->pluck('id');

            foreach ($this->selected_physical_books as $book) {

                $status = $book['status'] ?? 'paid';

                $existing = StudentBookFee::where([
                    'student_id' => $this->student->id,
                    'physical_book_id' => $book['id'],
                ])->first();

                StudentBookFee::updateOrCreate(
                    [
                        'student_id' => $this->student->id,
                        'physical_book_id' => $book['id'],
                    ],
                    [
                        'branch_id' => $this->student->branch_id,
                        'price' => $book['price'],
                        'status' => $status,
                        'payment_date' => $status === 'requested_exemption' ? null : now()->toDateString(),
                        'user_id' => Auth::id(),
                    ]
                );
                // notification
                if ($status === 'requested_exemption') {

                    $users = User::whereHas('role', function ($q) {
                        $q->where('role_name', 'Academic Admin');
                    })
                    ->where('branch_id', $this->student->branch_id)
                    ->get();

                    \Notification::send(
                        $users,
                        new BookExemptionRequestNotification(
                            $this->student,
                            $book,
                            $this->active_menu_id
                        )
                    );
                }

                if ($status === 'paid' && (!$existing || $existing->status !== 'paid')) {

                    $inventory = BookInventory::where('book_id', $book['id'])
                        ->whereIn('warehouse_id', $warehouseIds)
                        ->where('quantity', '>', 0)
                        ->lockForUpdate()
                        ->orderBy('quantity', 'desc')
                        ->first();

                    if (!$inventory) {
                        throw new \Exception('Book "' . ($book['name'] ?? '') . '" is not available in this branch inventory.');
                    }

                    $before = $inventory->quantity;
                    $new_quantity = $before - 1;

                    $inventory->update([
                        'quantity' => $new_quantity
                    ]);

                    BookInventoryMovement::create([
                        'book_inventory_id' => $inventory->id,
                        'quantity_change' => -1,
                        'balance_after' => $new_quantity,
                        'unit_price' => $book['price'] ?? 0,
                        'type' => 'sale',
                        'note' => 'Sold to student ID: ' . $this->student->student_code,
                        'user_id' => auth()->id(),
                    ]);
                }
            }


            //  فعال شدن شاگرد در کورس (فقط اگر پرداخت داشته باشد)
            if ($paid > 0) {
                $course_student = CourseStudent::where('student_id', $this->student->id)
                    ->where('course_id', $this->course_id)
                    ->firstOrFail();

                $course_student->update([
                    'status' => 'active'
                ]);
            }

            //  لاگ سیستم
            SystemLog::create([
                'st_id' => $this->student->id,
                'user_id' => Auth::user()->id,
                'section' => 'Student Course Fee (' . $studentCourseFee->course?->name . ' ID:' . $studentCourseFee->id . ')',
                'type_id' => 2,
            ]);

            DB::commit();

            $this->closeModal();

            $this->dispatch('alert',
                type: 'success',
                message: __('label.successfully_done')
            );

        } catch (\Exception $e) {

            DB::rollBack();

            $this->dispatch('alert',
                type: 'error',
                message: __('label.store_error') . ': ' . $e->getMessage()
            );
        }
    }

    public $remaining_discount = 0;
    public $used_discount = 0;
    public $discount_progress = 0;
    public $discount_provider_error = null;

    public function loadProviderDiscountInfo()
    {
        if(!$this->discount_provider_id){
            $this->remaining_discount = 0;
            $this->used_discount = 0;
            $this->discount_progress = 0;
            return;
        }

        $provider = DiscountProvider::find($this->discount_provider_id);

        if(!$provider){
            return;
        }

        // مقدار استفاده شده این ماه
        $this->used_discount = StudentCourseFee::where('discount_provider_id',$provider->id)
            ->whereMonth('created_at', Carbon::now()->month)
            ->whereYear('created_at', Carbon::now()->year)
            ->sum('discount_amount');
        
        // مقدار باقی مانده
        $this->remaining_discount = $provider->monthly_discount_total - $this->used_discount;

        if($this->remaining_discount < 0){
            $this->remaining_discount = 0;
        }

        // progress
        if($provider->monthly_discount_total > 0){
            $this->discount_progress =
                ($this->used_discount / $provider->monthly_discount_total) * 100;
        }

        // بررسی تخفیف جدید
        $newDiscount = $this->discount_value;

        if($this->discount_type == 'percentage'){
            $newDiscount = ($this->fee_amount * $this->discount_value) / 100;
        }

        if($newDiscount > $this->remaining_discount){

            $this->discount_provider_error =
                "Only {$this->remaining_discount} discount remaining for this provider this month.";

            return false;
        }

        $this->discount_provider_error = null;

        return true;
    }

    public function updatedDiscountProviderId()
    {
        $this->loadProviderDiscountInfo();
    }

  
    public $fee_installments = [];
    public $selected_fee_id;
    public $course_fee;
    public function showInstallments($fee_id)
    {
        $this->selected_fee_id = $fee_id;
        $this->course_fee = StudentCourseFee::find($fee_id);
        $this->fee_installments = StudentCourseFeeInstallment::where('student_course_fee_id',$fee_id)
            ->with('payments')
            ->get();

        $this->dispatch('open-modal', id: $this->installmentModalId);
    }

    public function openPayModal($id)
    {
        $this->installment_id = $id;
        $this->dispatch('open-modal', id: "payInstallmentModal");
    }

    public function payInstallment()
    {
        if (!add(Auth::user()->role_ids, $this->active_menu_id)) {
            return $this->dispatch('alert', type: 'error', message: __('label.permission_message'));
        }
        
        DB::beginTransaction();
       try {

            $installment = StudentCourseFeeInstallment::find($this->installment_id);

            if (!$installment) {
                return;
            }

            if ($installment->status == 'paid') {
                return;
            }

            $fee = StudentCourseFee::find($installment->student_course_fee_id);

            StudentCourseFeePayment::firstOrCreate(
                ['installment_id' => $installment->id],
                [
                    'student_course_fee_id' => $installment->student_course_fee_id,
                    'amount' => $installment->amount,
                    'payment_date' => now(),
                    'notes' => 'Installment payment',
                    'user_id' => auth()->id(),
                ]
            );

            $installment->update([
                'status' => 'paid'
            ]);

            $fee->paid_amount += $installment->amount;
            $fee->remaining_amount = $fee->total_amount - $fee->paid_amount;

            if ($fee->remaining_amount <= 0) {
                $fee->status = 'paid';
            } else {
                $fee->status = 'partial';
            }

            $fee->save();

            DB::commit();
            $this->dispatch('close-modal', id: "payInstallmentModal");
            $this->showInstallments($installment->student_course_fee_id);
            $this->dispatch('alert',
                type: 'success',
                message: __('label.successfully_done')
            );
            
        } catch (\Exception $e) {

            DB::rollBack();
            $this->dispatch('alert',
                type: 'error',
                message: __('label.store_error') . ': ' . $e->getMessage()
            );
        }
    }

    public function handleGlobalDelete($payload)
    {

        if (!isset($payload['table']) || $payload['table'] !== $this->table_name) {
            return;
        }

        $this->delete($payload['id']);
    }

    public function delete($id)
    {
        if(!delete(Auth::user()->role_ids, $this->active_menu_id)) {
            return $this->dispatch('alert', type: 'error', message: __('label.permission_message'));
        }

        try {

            $fee = StudentCourseFee::findOrFail($id);
            SystemLog::create([
                'st_id' => $this->student->id,
                'user_id' => Auth::user()->id,
                'section' => 'Student Course Fee ('.$fee->course?->name.' ID:'.$fee->id.')',
                'type_id' => 4,
            ]);
            $fee->delete();
            $this->dispatch('alert', type: 'success', message: __('label.successfully_deleted'));
        } catch (\Exception $e) {
            $this->dispatch('alert', type: 'error', message: __('label.delete_error').' : ' . $e->getMessage());
        }
    }

    public $installmentToPrint;
    public $studentCourseFee;
    public function loadInstallmentForPrint($installmentId)
    {
        $this->installmentToPrint = StudentCourseFeeInstallment::with('payments')->find($installmentId);
        $this->studentCourseFee = $this->installmentToPrint->studentCourseFee;
        $this->dispatch('show-print-preview');
    }

    public $cancel_reason;
    public $installment_id;

    public function openCancelModal($id)
    {
        $this->installment_id = $id;
        $this->dispatch('open-modal', id: "cancelInstallmentModal");
    }

    public function cancelInstallment()
    {
        $this->validate([
            'cancel_reason' => 'required|string|max:255'
        ]);

        DB::beginTransaction();
       try {

            $installment = StudentCourseFeeInstallment::find($this->installment_id);

            $installment->update([
                'status' => 'cancelled',
                'cancel_reason' => $this->cancel_reason
            ]);

            $this->cancel_reason = null;
            
           // ---start system log-----------
            SystemLog::create([
                'st_id' => $this->student->id,
                'user_id' => Auth::user()->id,
                'section' => 'Installment Cancelled ('.$installment->course?->name.' ID:'.$installment->id.')',
                'type_id' => 3,
            ]);
            // ---end system log-------------
            $this->showInstallments($installment->student_course_fee_id);
            DB::commit();
            $this->dispatch('close-modal', id: 'cancelInstallmentModal');
            $this->dispatch('alert',type: 'success',message: __('label.successfully_done'));

        } catch (\Exception $e) {

            DB::rollBack();
            $this->dispatch('alert',type: 'error',message: __('label.store_error') . ': ' . $e->getMessage()
            );
        }
    }

    //-----start physical book-------------------------
    public function requestExemption($index)
    {
        $this->selected_physical_books[$index]['status'] = 'requested_exemption';
        $this->calculatePhysicalBooksTotal();
    }

    public function cancelExemption($index)
    {
        $this->selected_physical_books[$index]['status'] = 'paid';
        $this->calculatePhysicalBooksTotal();
    }
    public function calculatePhysicalBooksTotal()
    {
        $this->physical_books_total = collect($this->selected_physical_books)
            ->where('status', 'paid') 
            ->sum('price');
    }
    //-----end physical book--------------------------- 

    public function openPaymentModal($id)
    {
        $this->selected_fee_id = $id;
        $this->install_amount = null;
        $this->dispatch('open-modal', id: "openPaymentModal");
    }
    
    
    public $install_amount;
   public function updatedInstallAmount()
    {
        $fee = StudentCourseFee::find($this->selected_fee_id);

        if (!$fee) return;

        $total_installments = StudentCourseFeeInstallment::where('student_course_fee_id', $this->selected_fee_id)
            ->sum('amount');

        $remaining = $fee->total_amount - $total_installments;

        $this->resetErrorBag('install_amount');

        if ($remaining <= 0) {
            $this->install_amount = null; // پاک کردن input
            $this->addError('install_amount', "All installments have been paid. No more installments allowed.");
            return;
        }

        if ($this->install_amount !== null && $this->install_amount !== '') {
            if ($this->install_amount > $remaining) {
                $this->addError('install_amount', "Installment ({$this->install_amount}) cannot exceed remaining ({$remaining})");
            }
        }
    }
    
    public function storeInstallment()
    {
        $fee = StudentCourseFee::find($this->selected_fee_id);

        if (!$fee) {
            $this->dispatch('alert', type: 'error', message: 'Fee not found');
            return;
        }

        // مجموع اقساط قبلی
        $total_installments = StudentCourseFeeInstallment::where('student_course_fee_id', $this->selected_fee_id)
            ->sum('amount');

        $remaining = $fee->total_amount - $total_installments;

        $this->validate([
            'install_amount' => [
                'required',
                'numeric',
                'min:0',
                function ($attribute, $value, $fail) use ($remaining) {
                    if ($value > $remaining) {
                        $fail("Installment ({$value}) cannot exceed remaining ({$remaining})");
                    }
                },
            ],
        ]);

        DB::beginTransaction();

        try {

            //  ایجاد installment (پرداخت شده)
            $installment = StudentCourseFeeInstallment::create([
                'student_course_fee_id' => $this->selected_fee_id,
                'due_date' => now()->toDateString(),
                'amount' => $this->install_amount,
                'status' => 'paid',
            ]);

            //  ثبت payment
            StudentCourseFeePayment::create([
                'installment_id' => $installment->id,
                'student_course_fee_id' => $installment->student_course_fee_id,
                'amount' => $installment->amount,
                'payment_date' => now(),
                'notes' => 'Installment payment',
                'user_id' => auth()->id(),
            ]);

            //  آپدیت fee 
            $fee->paid_amount += $this->install_amount;
            $fee->remaining_amount = $fee->total_amount - $fee->paid_amount;

            if ($fee->remaining_amount <= 0) {
                $fee->status = 'paid';
            } else {
                $fee->status = 'partial';
            }

            $fee->save();

           
            if ($fee->paid_amount > 0) {
                CourseStudent::where('student_id', $fee->student_id)
                    ->where('course_id', $fee->course_id)
                    ->update(['status' => 'active']);
            }

            DB::commit();

            $this->showInstallments($this->selected_fee_id);
            $this->reset('install_amount');

            $this->dispatch('close-modal', id: 'openPaymentModal');
            $this->dispatch('alert', type: 'success', message: __('label.successfully_done'));

        } catch (\Exception $e) {

            DB::rollBack();

            $this->dispatch('alert', type: 'error', message: __('label.store_error') . ': ' . $e->getMessage());
        }
    }
}
